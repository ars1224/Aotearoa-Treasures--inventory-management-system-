#include "session.h"

// Define the global session user
SessionUser currentUser;
